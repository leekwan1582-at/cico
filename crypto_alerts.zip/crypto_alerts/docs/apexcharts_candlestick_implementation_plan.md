# Detailed Implementation Plan: Historical Price Candlestick Charts & Alert Overlay (ApexCharts.js)

This document provides the technical architecture and step-by-step implementation plan for **Interactive D1 Candlestick / Line Charts with Alert Overlays** using **ApexCharts.js**, backed by persistent database storage for historical OHLCV candle data.

---

## 1. Architecture & Data Flow Overview

```mermaid
flowchart TD
    subgraph Data Acquisition & Sync
      CCXT["CCXT (fetchOHLCV: 30D / D1)"] --> Svc["services/priceService.js"]
      Fallback["data/fallback_d1.json"] -->|Network / Geo-Block Fallback| Svc
    end

    subgraph Persistent Storage [MySQL 8.x / MariaDB]
      Svc -->|INSERT ... ON DUPLICATE KEY UPDATE| DB[("asset_ohlcv Table<br>(asset_id, candle_time, O, H, L, C, V)")]
    end

    subgraph Backend API [Express.js]
      DB -->|Query Last 30 Candles| Route["GET /api/assets/:id/candles?days=30"]
      AlertsTable[("price_alerts Table")] -->|Active Alerts for Overlay| Route
      Route -->|JSON Payload: { candles, alertLines }| Browser
    end

    subgraph Frontend Presentation [ApexCharts 8.8.1]
      Browser["views/partials/price_chart.ejs"] --> Apex["ApexCharts.js (Candlestick / Line)"]
      Apex --> Annotations["Y-Axis Annotations<br>(Target Price Lines: Green/Red)"]
    end
```

---

## 2. Database Schema Extension (Persistence Tier)

To avoid hitting rate limits or external exchange geo-blocking repeatedly on every client dashboard load, historical daily candles are persisted directly in MySQL.

### 2.1 Table DDL: `asset_ohlcv`
Create a dedicated historical table with a composite unique index on `(asset_id, candle_time)` to support idempotent updates (`INSERT ... ON DUPLICATE KEY UPDATE`):

```sql
-- Table 5: Asset OHLCV Historical Candles
CREATE TABLE IF NOT EXISTS asset_ohlcv (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    candle_time DATE NOT NULL,                         -- Day timestamp (YYYY-MM-DD)
    open_price DECIMAL(18, 8) NOT NULL,
    high_price DECIMAL(18, 8) NOT NULL,
    low_price DECIMAL(18, 8) NOT NULL,
    close_price DECIMAL(18, 8) NOT NULL,
    volume DECIMAL(24, 8) DEFAULT 0.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_asset_candle (asset_id, candle_time),
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
);
```

> **Why `UNIQUE KEY (asset_id, candle_time)`?**
> Daily closed candles never change once finalized, and the current day's candle gets updated continuously. The unique key enables bulk upserts (`INSERT ... ON DUPLICATE KEY UPDATE open_price=VALUES(open_price), high_price=VALUES(high_price), ...`) without duplicating daily records.

---

## 3. CCXT Historical Data Fetching & Sync Logic

### 3.1 CCXT Fetching Method
In `services/priceService.js`, extend price fetching to retrieve the last 30 daily candles via CCXT:

```javascript
// CCXT fetchOHLCV: symbol, timeframe='1d', since (30 days ago in ms), limit=30
const since = Date.now() - 30 * 24 * 60 * 60 * 1000;
const ohlcv = await exchange.fetchOHLCV(symbol, '1d', since, 30);
// Each candle: [ timestamp, open, high, low, close, volume ]
```

### 3.2 Idempotent Database Batch Upsert
Persist fetched candles into `asset_ohlcv` inside a transaction block:

```javascript
async function saveCandlesToDatabase(connection, assetId, candles) {
  const insertSql = `
    INSERT INTO asset_ohlcv (asset_id, candle_time, open_price, high_price, low_price, close_price, volume)
    VALUES ?
    ON DUPLICATE KEY UPDATE
      open_price = VALUES(open_price),
      high_price = VALUES(high_price),
      low_price = VALUES(low_price),
      close_price = VALUES(close_price),
      volume = VALUES(volume),
      updated_at = NOW()
  `;

  const values = candles.map((c) => {
    // c[0] is epoch ms timestamp
    const dateStr = new Date(c[0]).toISOString().slice(0, 10);
    return [assetId, dateStr, c[1], c[2], c[3], c[4], c[5]];
  });

  if (values.length > 0) {
    await connection.query(insertSql, [values]);
  }
}
```

### 3.3 Offline / Geo-Block Fallback Generation
If exchange APIs are unreachable, generate 30 days of realistic simulated historical candles anchored to `data/fallback_d1.json` so the chart always renders in sandbox/offline environments.

---

## 4. Backend Express API Endpoint

Expose a clean JSON endpoint for the frontend chart component:

### `GET /api/assets/:id/chart-data`

- **Parameters**: `id` (asset ID), optional `?user_id=1&days=30`
- **Output JSON Payload**:
```json
{
  "asset": {
    "id": 1,
    "symbol": "BTC/USDT",
    "name": "Bitcoin",
    "last_d1_close": 89200.0
  },
  "series": [
    {
      "x": "2026-11-01",
      "y": [87100.0, 88500.0, 86800.0, 88200.0]  // [Open, High, Low, Close]
    }
  ],
  "annotations": [
    {
      "id": 4,
      "target_price": 90000.0,
      "condition_type": "ABOVE",
      "borderColor": "#10b981",
      "label": "Target: ABOVE 90,000 (leekwan)"
    },
    {
      "id": 5,
      "target_price": 84000.0,
      "condition_type": "BELOW",
      "borderColor": "#ef4444",
      "label": "Target: BELOW 84,000 (leekwan)"
    }
  ]
}
```

---

## 5. Frontend UI Component & ApexCharts Integration

### 5.1 CDN Integration in `views/layout` / `views/index.ejs`
```html
<!-- ApexCharts 8.8.1 CDN -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts@8.8.1/dist/apexcharts.min.js"></script>
```

### 5.2 Chart Container Partial (`views/partials/price_chart.ejs`)
Place an interactive card directly above or alongside the watchlist table:

```html
<div class="card shadow-sm mb-4 border-0">
  <div class="card-header bg-body-tertiary d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
      <span class="fw-semibold">Asset Candlestick Chart (D1)</span>
      <!-- Asset Selector -->
      <select id="chartAssetSelect" class="form-select form-select-sm" style="width: auto;">
        <% assets.forEach(function(asset) { %>
          <option value="<%= asset.id %>"><%= asset.symbol %> (<%= asset.name %>)</option>
        <% }); %>
      </select>
    </div>
    <div class="btn-group btn-group-sm" role="group">
      <button type="button" class="btn btn-outline-secondary active" data-days="7">7D</button>
      <button type="button" class="btn btn-outline-secondary" data-days="30">30D</button>
    </div>
  </div>
  <div class="card-body p-2">
    <div id="apexCandleChart" style="min-height: 350px;"></div>
  </div>
</div>
```

### 5.3 ApexCharts Configuration & Alert Overlay Script (`public/js/chart.js`)

```javascript
let chartInstance = null;

async function loadChart(assetId, days = 30) {
  const response = await fetch(`/api/assets/${assetId}/chart-data?days=${days}`);
  const data = await response.json();

  // Map alert targets to ApexCharts Y-Axis annotations
  const yaxisAnnotations = data.annotations.map((alert) => ({
    y: alert.target_price,
    borderColor: alert.condition_type === "ABOVE" ? "#10b981" : "#ef4444",
    strokeDashArray: 4,
    label: {
      borderColor: alert.condition_type === "ABOVE" ? "#10b981" : "#ef4444",
      style: {
        color: "#fff",
        background: alert.condition_type === "ABOVE" ? "#10b981" : "#ef4444",
        fontSize: "11px",
        fontWeight: 600,
      },
      text: `${alert.condition_type} $${Number(alert.target_price).toLocaleString()}`,
    },
  }));

  const options = {
    series: [{
      name: "D1 Candle",
      data: data.series, // [{ x: 'YYYY-MM-DD', y: [open, high, low, close] }]
    }],
    chart: {
      type: "candlestick",
      height: 350,
      toolbar: { show: true, tools: { zoom: true, reset: true } },
      background: "transparent",
    },
    title: {
      text: `${data.asset.symbol} - 30-Day Daily OHLCV with Active Price Alerts`,
      align: "left",
      style: { fontSize: "14px", fontWeight: 600 },
    },
    annotations: {
      yaxis: yaxisAnnotations,
    },
    xaxis: {
      type: "datetime",
      labels: { datetimeUTC: false },
    },
    yaxis: {
      tooltip: { enabled: true },
      labels: {
        formatter: (val) => `$${Number(val).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      },
    },
    theme: {
      mode: document.documentElement.getAttribute("data-bs-theme") === "dark" ? "dark" : "light",
    },
  };

  if (chartInstance) {
    chartInstance.destroy();
  }
  chartInstance = new ApexCharts(document.querySelector("#apexCandleChart"), options);
  await chartInstance.render();
}
```

---

## 6. Implementation Checklist & Phase Steps

- [ ] **Step 1: Database Migration**:
  - Add `asset_ohlcv` table definition into `sql/schema.sql` and run table migration in MySQL.
  - Update `seed.js` to seed initial 30-day baseline candles for BTC, ETH, and SOL.
- [ ] **Step 2: Service Layer (`priceService.js`)**:
  - Implement `fetchAndSaveOHLCV(assetId, symbol, days)` with CCXT `fetchOHLCV` and offline fallback.
  - Connect sync inside `refreshAllPrices()` to update both latest D1 close and historical candle rows.
- [ ] **Step 3: Route Layer (`alertRoutes.js`)**:
  - Implement `GET /api/assets/:id/chart-data`.
  - Perform JOIN query on `asset_ohlcv` and `price_alerts` (filtering `is_triggered = FALSE`).
- [ ] **Step 4: Frontend View & Script**:
  - Add ApexCharts 8.8.1 CDN `<script>` tag.
  - Render `views/partials/price_chart.ejs` on dashboard.
  - Create `public/js/chart.js` with theme change observer (`MutationObserver` on `data-bs-theme`) so chart colors dynamically update when toggling dark/light mode.
- [ ] **Step 5: Testing & Verification**:
  - Add unit/integration tests for `GET /api/assets/:id/chart-data`.
  - Validate empty candle recovery, mock CCXT OHLCV response, and verify all 21+ test suites pass.
